<script>
window.onload = function() {
	window.location.href = 'publica/index.php';
	};
	</script>